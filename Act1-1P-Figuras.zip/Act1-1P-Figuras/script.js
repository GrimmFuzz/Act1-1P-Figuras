function mostrarFormulario() {
    const figura = document.getElementById("figura").value;
    const formularioDiv = document.getElementById("formulario-figuras");
    formularioDiv.innerHTML = ""; 
    let formularioHtml = "";
    let imagenUrl = "";

    if (figura === "rectangulo") {
        imagenUrl = "rectangulo.png"; 
        formularioHtml = `
            <img src="${imagenUrl}" alt="Rectángulo" width="100">
            <input type="number" id="rectLargo" placeholder="Largo" step="0.1">
            <input type="number" id="rectAncho" placeholder="Ancho" step="0.1">
            <button onclick="calcularRectangulo()">Calcular</button>
        `;
    } else if (figura === "circulo") {
        imagenUrl = "circulo.png";
        formularioHtml = `
            <img src="${imagenUrl}" alt="Círculo" width="100">
            <input type="number" id="cirRadio" placeholder="Radio" step="0.1">
            <button onclick="calcularCirculo()">Calcular</button>
        `;
    } else if (figura === "cuadrado") {
        imagenUrl = "cuadrado.png";
        formularioHtml = `
            <img src="${imagenUrl}" alt="Cuadrado" width="100">
            <input type="number" id="cuadLado" placeholder="Lado" step="0.1">
            <button onclick="calcularCuadrado()">Calcular</button>
        `;
    } else if (figura === "triangulo") {
        imagenUrl = "triangulo.png";
        formularioHtml = `
            <img src="${imagenUrl}" alt="Triángulo" width="100">
            <input type="number" id="triBase" placeholder="Base" step="0.1">
            <input type="number" id="triAltura" placeholder="Altura" step="0.1">
            <input type="number" id="triLado1" placeholder="Lado 1" step="0.1">
            <input type="number" id="triLado2" placeholder="Lado 2" step="0.1">
            <input type="number" id="triLado3" placeholder="Lado 3" step="0.1">
            <button onclick="calcularTriangulo()">Calcular</button>
        `;
    }

    formularioDiv.innerHTML = formularioHtml;
}

function mostrarResultado(resultado) {
    const resultadosDiv = document.getElementById("resultados");
    resultadosDiv.innerHTML = `<h2>${resultado}</h2>`;
}

function calcularRectangulo() {
    const largo = parseFloat(document.getElementById("rectLargo").value);
    const ancho = parseFloat(document.getElementById("rectAncho").value);
    if (isNaN(largo) || isNaN(ancho) || largo < 0 || ancho < 0) {
        mostrarResultado("Introduce valores válidos y no negativos.");
        return;
    }
    const perimetro = 2 * (largo + ancho);
    const area = largo * ancho;
    mostrarResultado(`Perímetro: ${perimetro} - Área: ${area}`);
}

function calcularCirculo() {
    const radio = parseFloat(document.getElementById("cirRadio").value);
    if (isNaN(radio) || radio < 0) {
        mostrarResultado("Introduce un valor válido y no negativo.");
        return;
    }
    const perimetro = 2 * Math.PI * radio;
    const area = Math.PI * radio * radio;
    mostrarResultado(`Perímetro: ${perimetro.toFixed(2)} - Área: ${area.toFixed(2)}`);
}

function calcularCuadrado() {
    const lado = parseFloat(document.getElementById("cuadLado").value);
    if (isNaN(lado) || lado < 0) {
        mostrarResultado("Introduce un valor válido y no negativo.");
        return;
    }
    const perimetro = 4 * lado;
    const area = lado * lado;
    mostrarResultado(`Perímetro: ${perimetro} - Área: ${area}`);
}

function calcularTriangulo() {
    const base = parseFloat(document.getElementById("triBase").value);
    const altura = parseFloat(document.getElementById("triAltura").value);
    const lado1 = parseFloat(document.getElementById("triLado1").value);
    const lado2 = parseFloat(document.getElementById("triLado2").value);
    const lado3 = parseFloat(document.getElementById("triLado3").value);

    if (isNaN(base) || isNaN(altura) || isNaN(lado1) || isNaN(lado2) || isNaN(lado3) || base < 0 || altura < 0 || lado1 < 0 || lado2 < 0 || lado3 < 0) {
        mostrarResultado("Introduce valores válidos y no negativos.");
        return;
    }

    const area = (base * altura) / 2;
    const perimetro = lado1 + lado2 + lado3;

    mostrarResultado(`Perímetro: ${perimetro} - Área: ${area}`);
}
